<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Master_Bank extends Model
{
    //
    protected $tables = "data_master_banks";
}
