<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class M_bank extends Model
{
    //
    protected $table = 'm_banks';
}
