<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction_Time_Deposit extends Model
{
    //
}
