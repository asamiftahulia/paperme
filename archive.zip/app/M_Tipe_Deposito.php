<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class M_Tipe_Deposito extends Model
{
    //
    protected $table = 'm__tipe__depositos';
     protected $primaryKey = 'id_deposito';
}
