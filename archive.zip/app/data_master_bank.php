<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class data_master_bank extends Model
{
    //
}
