<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TimeDeposit extends Model
{
    //
    protected $table = 'time_deposits';
    protected $primaryKey ='id_td';
}
