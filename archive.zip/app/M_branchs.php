<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class M_branchs extends Model
{
    //
    protected $table = 'm_branchs';
}
