<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterBank extends Model
{
    //
    protected $table = "master_banks";
}
